#include "search_server.h"
#include "iterator_range.h"

#include <algorithm>
#include <iterator>
#include <sstream>
#include <iostream>
#include <numeric>
#include <vector>


void SearchServer::UpdateDocumentBase(istream& document_input) {
    index = InvertedIndex{document_input};
}

void SearchServer::AddQueriesStream(
        istream& query_input, ostream& search_results_output
) {

    const auto& documents = index.GetDocument();

    vector<size_t> docid_count(documents.size());
    vector <int64_t> docids(documents.size());

    for (string current_query; getline(query_input, current_query); ) {

        vector<string_view> words = SplitIntoWords(current_query);
        docid_count.assign(docid_count.size(), 0);

        for (const auto& word : words) {

            for (const auto& [docid, hitcount]: index.Lookup(word)) {

                docid_count[docid]+= hitcount;
            }
        }

        iota(docids.begin(), docids.end(), 0);

        partial_sort(
                begin(docids),
                Head(docids, 5).end(),
                end(docids),
                [&docid_count](int64_t lhs, int64_t rhs) {
                    return make_pair(docid_count[lhs], -lhs) > make_pair(docid_count[rhs], -rhs);
                }
        );

        search_results_output << current_query << ':';
        for (size_t docid : Head(docids, 5)) {
            
            const size_t hitcount = docid_count[docid];
            if (hitcount == 0) {
                break;
            }
            search_results_output << " {"
                                  << "docid: " << docid << ", "
                                  << "hitcount: " << hitcount << '}';
        }
        search_results_output << '\n';
    }
}
