#include "test_search_server.h"


int main()
{
    TestSearchServer();

    return 0;
}