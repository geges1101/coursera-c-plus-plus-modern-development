#pragma once

#include "http_request.h"

#include <string_view>
#include <map>
using namespace std;

class Stats {
public:
    Stats(){
        methods = {
                {"GET", 0},
                {"PUT", 0},
                {"POST", 0},
                {"DELETE", 0},
                {"UNKNOWN", 0}
        };

        uris = {
                {"/", 0},
                {"/order", 0},
                {"/product", 0},
                {"/basket", 0},
                {"/help", 0},
                {"unknown", 0}
        };
    }

    void AddMethod(string_view method){
        if(methods.find(method) != methods.end()){
            methods[method]++;
        }
        else methods["UNKNOWN"]++;
    }

    void AddUri(string_view uri){
        if(uris.find(uri) != uris.end()){
            uris[uri]++;
        }
        else uris["unknown"]++;
    }

    const map<string_view, int>& GetMethodStats() const {
        return methods;
    }
    const map<string_view, int>& GetUriStats() const {
        return uris;
    }

private:
    map <string_view, int> methods;
    map <string_view, int> uris;
};

HttpRequest ParseRequest(string_view line);